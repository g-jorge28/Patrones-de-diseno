﻿using Adapter;
using System;

namespace PatronesEstructurales.Adapter
{
    // 4. Código Cliente
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("EJEMPLO PATRÓN ADAPTER");

            // El cliente trabaja únicamente con la interfaz IProcesadorPago
            IProcesadorPago procesador = new NequiAdapter(new Nequi()); // <-- crear y asignar

            // El cliente llama al método común sin preocuparse por la API interna
            procesador.RealizarPago("usuario@email.com", 150000m);
        }
    }


}