﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Adapter
{
// 1. Interfaz que espera el Cliente (Client Interface)
    public interface IProcesadorPago
    {
        void RealizarPago(string cuenta, decimal monto);
    }
}

