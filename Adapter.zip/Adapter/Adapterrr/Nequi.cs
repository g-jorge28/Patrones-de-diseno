﻿using System;

namespace PatronesEstructurales.Adapter
{
    // 2. Servicio de terceros o clase existente con interfaz incompatible (Adaptee / Service)
    public class Nequi
    {
        // Nota cómo los nombres de métodos y parámetros son totalmente diferentes
        public void EnviarTransferencia(decimal valor, string usuarioEmail)
        {
            Console.WriteLine($"[Nequi] Transacción exitosa de ${valor} COP para la cuenta: {usuarioEmail}");
        }
    }
}