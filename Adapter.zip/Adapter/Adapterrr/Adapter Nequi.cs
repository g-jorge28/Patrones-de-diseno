﻿using Adapter;
using System;

namespace PatronesEstructurales.Adapter
{
    // 3. El Adaptador (Adapter)
    // Implementa la interfaz esperada por el cliente y envuelve el servicio incompatible
    public class NequiAdapter : IProcesadorPago
    {
        private readonly Nequi _nequi;

        public NequiAdapter(Nequi nequi)
        {
            _nequi = nequi;
        }

        // Traduce la llamada estándar del cliente hacia la interfaz específica de Nequi
        public void RealizarPago(string cuenta, decimal monto)
        {
            Console.WriteLine("[Adapter] Traduciendo 'RealizarPago' a 'EnviarTransferencia' de Nequi...");
            _nequi.EnviarTransferencia(monto, cuenta);
        }
    }


}